import { TemplateNav } from "@/components/TemplateNav";
import { Star, MapPin, Phone, Clock, Utensils } from "lucide-react";

const sections = [
  { id: "home", label: "Home" },
  { id: "about", label: "About" },
  { id: "menu", label: "Menu" },
  { id: "features", label: "Features" },
  { id: "testimonials", label: "Reviews" },
  { id: "contact", label: "Contact" },
];

const dishes = [
  { name: "Truffle Risotto", price: "$28", desc: "Arborio rice, black truffle, parmigiano." },
  { name: "Seared Scallops", price: "$34", desc: "Cauliflower purée, citrus beurre blanc." },
  { name: "Wagyu Tagliata", price: "$48", desc: "Arugula, shaved pecorino, balsamic glaze." },
  { name: "Dark Chocolate Tart", price: "$14", desc: "Sea salt, vanilla cream, raspberry." },
];

export function RestaurantTemplate() {
  return (
    <div className="min-h-screen">
      <TemplateNav brand="Maison Olive" sections={sections} cta={{ label: "Reserve a Table", href: "#contact" }} />

      <section id="home" className="relative min-h-[90vh] flex items-center pt-28 bg-hero">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_oklch(0.82_0.12_85/0.15),transparent_60%)]" />
        <div className="container mx-auto px-4 relative">
          <div className="max-w-2xl animate-fade-up">
            <span className="text-xs uppercase tracking-[0.3em] text-gold">Est. 2014 · Italian Fine Dining</span>
            <h1 className="mt-4 text-5xl md:text-7xl font-bold leading-tight">A taste of <span className="text-gradient">la dolce vita</span></h1>
            <p className="mt-6 text-lg text-muted-foreground">Seasonal Italian dishes crafted with care, served in an intimate dining room in the heart of downtown.</p>
            <div className="mt-8 flex gap-3">
              <a href="#contact" className="rounded-full bg-primary text-primary-foreground px-6 py-3 font-medium shadow-elegant">Reserve a Table</a>
              <a href="#menu" className="rounded-full glass px-6 py-3 font-medium">View Menu</a>
            </div>
          </div>
        </div>
      </section>

      <section id="about" className="py-24 container mx-auto px-4 grid md:grid-cols-2 gap-12 items-center">
        <div className="aspect-[4/5] rounded-3xl bg-gradient-to-br from-primary/30 to-gold/30 shadow-elegant" />
        <div>
          <span className="text-xs uppercase tracking-[0.3em] text-primary">About</span>
          <h2 className="mt-3 text-4xl font-bold">Family-run since 1998</h2>
          <p className="mt-5 text-muted-foreground leading-relaxed">Chef Antonio Russo brings three generations of Sicilian tradition to a modern table. Every plate tells a story — sourced from local farms and the finest Italian imports.</p>
          <div className="mt-6 grid grid-cols-3 gap-4">
            <Stat n="25+" l="Years cooking" />
            <Stat n="4.9★" l="Google rating" />
            <Stat n="40" l="Seats nightly" />
          </div>
        </div>
      </section>

      <section id="menu" className="py-24 container mx-auto px-4">
        <Heading eyebrow="Featured Dishes" title="Tonight's tasting" />
        <div className="mt-12 grid md:grid-cols-2 gap-5">
          {dishes.map((d) => (
            <div key={d.name} className="glass rounded-2xl p-6 hover:shadow-elegant transition">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h3 className="text-xl font-semibold">{d.name}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{d.desc}</p>
                </div>
                <span className="text-gold font-semibold">{d.price}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section id="features" className="py-24 container mx-auto px-4">
        <Heading eyebrow="The Experience" title="More than a meal" />
        <div className="mt-12 grid sm:grid-cols-3 gap-5">
          {[
            { icon: Utensils, t: "Seasonal Tasting", d: "A new 5-course menu every month." },
            { icon: Clock, t: "Open Wed–Sun", d: "Dinner from 5:30pm, last seating 10pm." },
            { icon: MapPin, t: "Downtown", d: "124 Vine Street, walk-ins welcome at the bar." },
          ].map((f) => (
            <div key={f.t} className="rounded-2xl bg-card border border-border/60 p-6">
              <f.icon className="size-6 text-primary" />
              <h3 className="mt-4 font-semibold">{f.t}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{f.d}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="testimonials" className="py-24 container mx-auto px-4">
        <Heading eyebrow="Reviews" title="Loved by our guests" />
        <div className="mt-12 grid md:grid-cols-3 gap-5">
          {[
            { n: "Alana R.", q: "Best risotto outside of Italy. The room glows." },
            { n: "Marco T.", q: "Service like family. Wine pairings were spot on." },
            { n: "Joon P.", q: "Special-occasion worthy — every single visit." },
          ].map((t) => (
            <div key={t.n} className="glass rounded-2xl p-6">
              <div className="flex gap-1 text-gold">{Array.from({ length: 5 }).map((_, i) => <Star key={i} className="size-4 fill-current" />)}</div>
              <p className="mt-3 text-sm">"{t.q}"</p>
              <div className="mt-4 text-sm font-semibold">{t.n}</div>
            </div>
          ))}
        </div>
      </section>

      <section id="contact" className="py-24 container mx-auto px-4 max-w-4xl">
        <Heading eyebrow="Reservations" title="Book your table" />
        <div className="mt-12 grid md:grid-cols-2 gap-8">
          <form className="glass rounded-3xl p-6 space-y-3" onSubmit={(e) => e.preventDefault()}>
            <input placeholder="Name" className="w-full rounded-xl bg-background border border-border px-4 py-3 text-sm" />
            <input placeholder="Email" type="email" className="w-full rounded-xl bg-background border border-border px-4 py-3 text-sm" />
            <div className="grid grid-cols-2 gap-3">
              <input type="date" className="rounded-xl bg-background border border-border px-4 py-3 text-sm" />
              <input type="time" className="rounded-xl bg-background border border-border px-4 py-3 text-sm" />
            </div>
            <input type="number" placeholder="Party size" className="w-full rounded-xl bg-background border border-border px-4 py-3 text-sm" />
            <button className="w-full rounded-full bg-primary text-primary-foreground px-5 py-3 font-medium shadow-elegant">Request Reservation</button>
          </form>
          <div className="space-y-4 text-sm">
            <Info icon={MapPin} t="124 Vine Street, Downtown" />
            <Info icon={Phone} t="(415) 555-0182" />
            <Info icon={Clock} t="Wed–Sun · 5:30pm – 10:30pm" />
            <div className="aspect-video rounded-2xl bg-gradient-to-br from-primary/20 to-gold/20" />
          </div>
        </div>
      </section>

      <DemoFooter brand="Maison Olive" />
    </div>
  );
}

function Stat({ n, l }: { n: string; l: string }) { return <div><div className="text-2xl font-bold text-gradient">{n}</div><div className="text-xs text-muted-foreground mt-1">{l}</div></div>; }
function Heading({ eyebrow, title }: { eyebrow: string; title: string }) { return <div className="text-center"><span className="text-xs uppercase tracking-[0.3em] text-primary font-semibold">{eyebrow}</span><h2 className="mt-3 text-4xl md:text-5xl font-bold">{title}</h2></div>; }
function Info({ icon: Icon, t }: { icon: React.ComponentType<{ className?: string }>; t: string }) { return <div className="flex items-center gap-3"><Icon className="size-4 text-primary" /><span>{t}</span></div>; }
function DemoFooter({ brand }: { brand: string }) {
  return <footer className="border-t border-border/60 mt-24 py-8 text-center text-xs text-muted-foreground">© {new Date().getFullYear()} {brand} · Demo template by Tadylcor</footer>;
}
