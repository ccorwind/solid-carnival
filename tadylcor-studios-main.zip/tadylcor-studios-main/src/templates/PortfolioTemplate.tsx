import { TemplateNav } from "@/components/TemplateNav";
import { Star, Github, Linkedin, Mail, ArrowUpRight } from "lucide-react";

const sections = [
  { id: "home", label: "Home" },
  { id: "about", label: "About" },
  { id: "services", label: "Skills" },
  { id: "features", label: "Portfolio" },
  { id: "testimonials", label: "Praise" },
  { id: "contact", label: "Contact" },
];

const works = [
  { t: "Lumen Branding", c: "Identity · 2025", grad: "from-gold/40 to-primary/40" },
  { t: "Northwind App", c: "Product · 2025", grad: "from-primary/40 to-accent/40" },
  { t: "Field Notes Zine", c: "Editorial · 2024", grad: "from-accent/40 to-gold/40" },
  { t: "Atlas Studios", c: "Web · 2024", grad: "from-primary/30 to-gold/30" },
  { t: "Halo Watch", c: "Industrial · 2024", grad: "from-gold/30 to-accent/30" },
  { t: "Pulse Audio", c: "Product · 2023", grad: "from-accent/30 to-primary/30" },
];

export function PortfolioTemplate() {
  return (
    <div className="min-h-screen">
      <TemplateNav brand="Iris Chen" sections={sections} cta={{ label: "Work with me", href: "#contact" }} />

      <section id="home" className="relative min-h-[90vh] flex items-center pt-28 bg-hero">
        <div className="container mx-auto px-4 max-w-4xl animate-fade-up">
          <span className="text-xs uppercase tracking-[0.3em] text-gold">Independent Designer · SF / Remote</span>
          <h1 className="mt-4 text-6xl md:text-8xl font-bold leading-[0.95] tracking-tight">
            I design <span className="text-gradient">brands & products</span> people remember.
          </h1>
          <p className="mt-8 text-lg text-muted-foreground max-w-2xl">Selected work for startups, studios, and culture brands — from identity systems to interactive products.</p>
          <div className="mt-10 flex gap-3">
            <a href="#features" className="rounded-full bg-primary text-primary-foreground px-6 py-3 font-medium shadow-elegant">View Portfolio</a>
            <a href="#contact" className="rounded-full glass px-6 py-3 font-medium">Get in touch</a>
          </div>
        </div>
      </section>

      <section id="about" className="py-24 container mx-auto px-4 grid md:grid-cols-2 gap-12 items-center">
        <div className="aspect-[4/5] rounded-3xl bg-gradient-to-br from-gold/30 to-primary/30 shadow-elegant max-w-sm" />
        <div>
          <span className="text-xs uppercase tracking-[0.3em] text-primary">About</span>
          <h2 className="mt-3 text-4xl font-bold">Hi, I'm Iris.</h2>
          <p className="mt-5 text-muted-foreground leading-relaxed">I've spent the last 8 years helping ambitious teams turn fuzzy ideas into clear, beautiful products. Previously at IDEO and Linear. Now independent, taking on a small number of projects each quarter.</p>
          <div className="mt-6 flex gap-3">
            <a className="glass rounded-full p-2.5"><Github className="size-4" /></a>
            <a className="glass rounded-full p-2.5"><Linkedin className="size-4" /></a>
            <a className="glass rounded-full p-2.5"><Mail className="size-4" /></a>
          </div>
        </div>
      </section>

      <section id="services" className="py-24 container mx-auto px-4">
        <Heading eyebrow="Skills" title="What I do" />
        <div className="mt-12 grid md:grid-cols-3 gap-5">
          {[
            { t: "Brand Identity", d: "Strategy, logo, typography, guidelines." },
            { t: "Product Design", d: "Web and mobile interfaces end-to-end." },
            { t: "Art Direction", d: "Campaigns, editorial, motion." },
          ].map((s) => (
            <div key={s.t} className="glass rounded-2xl p-6">
              <h3 className="text-lg font-semibold">{s.t}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{s.d}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="features" className="py-24 container mx-auto px-4">
        <Heading eyebrow="Portfolio" title="Selected work" />
        <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {works.map((w) => (
            <a key={w.t} className="group block">
              <div className={`aspect-[4/5] rounded-3xl bg-gradient-to-br ${w.grad} shadow-soft group-hover:shadow-elegant transition`} />
              <div className="mt-4 flex items-center justify-between">
                <div>
                  <h3 className="font-semibold">{w.t}</h3>
                  <p className="text-xs text-muted-foreground">{w.c}</p>
                </div>
                <ArrowUpRight className="size-5 text-muted-foreground group-hover:text-primary transition" />
              </div>
            </a>
          ))}
        </div>
      </section>

      <section id="testimonials" className="py-24 container mx-auto px-4">
        <Heading eyebrow="Praise" title="Kind words" />
        <div className="mt-12 grid md:grid-cols-3 gap-5">
          {[
            { n: "Ana — Northwind", q: "Iris transformed our product. Clear vision, calm process." },
            { n: "James — Lumen", q: "Best brand work we've ever shipped. Total partner." },
            { n: "Sara — Atlas", q: "Sharp taste, sharper thinking. Hire her yesterday." },
          ].map((t) => (
            <div key={t.n} className="glass rounded-2xl p-6">
              <div className="flex gap-1 text-gold">{Array.from({ length: 5 }).map((_, i) => <Star key={i} className="size-4 fill-current" />)}</div>
              <p className="mt-3 text-sm">"{t.q}"</p>
              <div className="mt-4 text-sm font-semibold">{t.n}</div>
            </div>
          ))}
        </div>
      </section>

      <section id="contact" className="py-24 container mx-auto px-4 max-w-3xl">
        <Heading eyebrow="Contact" title="Start a project" />
        <form className="mt-12 glass rounded-3xl p-8 grid sm:grid-cols-2 gap-4" onSubmit={(e) => e.preventDefault()}>
          <input placeholder="Name" className="rounded-xl bg-background border border-border px-4 py-3 text-sm" />
          <input placeholder="Email" type="email" className="rounded-xl bg-background border border-border px-4 py-3 text-sm" />
          <input placeholder="Company / project" className="sm:col-span-2 rounded-xl bg-background border border-border px-4 py-3 text-sm" />
          <textarea rows={5} placeholder="Tell me about what you're building…" className="sm:col-span-2 rounded-xl bg-background border border-border px-4 py-3 text-sm" />
          <button className="sm:col-span-2 rounded-full bg-primary text-primary-foreground px-5 py-3 font-medium shadow-elegant">Send Message</button>
        </form>
      </section>

      <footer className="border-t border-border/60 mt-24 py-8 text-center text-xs text-muted-foreground">© {new Date().getFullYear()} Iris Chen · Demo template by Tadylcor</footer>
    </div>
  );
}

function Heading({ eyebrow, title }: { eyebrow: string; title: string }) { return <div className="text-center"><span className="text-xs uppercase tracking-[0.3em] text-primary font-semibold">{eyebrow}</span><h2 className="mt-3 text-4xl md:text-5xl font-bold">{title}</h2></div>; }
