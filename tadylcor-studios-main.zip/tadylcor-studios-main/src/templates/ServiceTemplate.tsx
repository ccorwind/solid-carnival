import { TemplateNav } from "@/components/TemplateNav";
import { Star, Wrench, Hammer, Sparkles, ShieldCheck, Phone, Mail, MapPin } from "lucide-react";

const sections = [
  { id: "home", label: "Home" },
  { id: "about", label: "About" },
  { id: "services", label: "Services" },
  { id: "features", label: "Why Us" },
  { id: "testimonials", label: "Testimonials" },
  { id: "contact", label: "Contact" },
];

export function ServiceTemplate() {
  return (
    <div className="min-h-screen">
      <TemplateNav brand="Ortiz & Co." sections={sections} cta={{ label: "Get a Free Quote", href: "#contact" }} />

      <section id="home" className="relative min-h-[85vh] flex items-center pt-28 bg-hero">
        <div className="container mx-auto px-4 grid md:grid-cols-2 gap-12 items-center">
          <div className="animate-fade-up">
            <span className="text-xs uppercase tracking-[0.3em] text-gold">Licensed · Insured · 24/7</span>
            <h1 className="mt-4 text-5xl md:text-6xl font-bold leading-tight">Reliable home services, <span className="text-gradient">done right the first time</span></h1>
            <p className="mt-6 text-lg text-muted-foreground">Plumbing, HVAC and electrical repairs from a local team trusted by 1,500+ homeowners.</p>
            <div className="mt-8 flex gap-3">
              <a href="#contact" className="rounded-full bg-primary text-primary-foreground px-6 py-3 font-medium shadow-elegant">Get a Free Quote</a>
              <a href="tel:5551234" className="rounded-full glass px-6 py-3 font-medium inline-flex items-center gap-2"><Phone className="size-4" /> Call Now</a>
            </div>
          </div>
          <div className="aspect-square rounded-3xl bg-gradient-to-br from-primary/30 via-accent/30 to-gold/30 shadow-elegant" />
        </div>
      </section>

      <section id="about" className="py-24 container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <span className="text-xs uppercase tracking-[0.3em] text-primary">About</span>
            <h2 className="mt-3 text-4xl font-bold">A local team you can trust</h2>
            <p className="mt-5 text-muted-foreground leading-relaxed">Founded by Daniel Ortiz in 2009, we serve the Bay Area with a no-surprises pricing model and a 1-year workmanship guarantee on every job.</p>
            <div className="mt-6 grid grid-cols-3 gap-4">
              <Stat n="15+" l="Years" /><Stat n="1,500+" l="Homes served" /><Stat n="4.9★" l="Google reviews" />
            </div>
          </div>
          <div className="aspect-video rounded-3xl bg-gradient-to-br from-accent/30 to-primary/20 shadow-elegant" />
        </div>
      </section>

      <section id="services" className="py-24 container mx-auto px-4">
        <Heading eyebrow="Services" title="What we do" />
        <div className="mt-12 grid md:grid-cols-3 gap-5">
          {[
            { icon: Wrench, t: "Plumbing", d: "Leaks, fixtures, water heaters, re-pipes." },
            { icon: Hammer, t: "HVAC", d: "Installation, repair, seasonal tune-ups." },
            { icon: Sparkles, t: "Electrical", d: "Outlets, panels, lighting, EV chargers." },
          ].map((s) => (
            <div key={s.t} className="glass rounded-2xl p-7 hover:shadow-elegant transition">
              <s.icon className="size-7 text-primary" />
              <h3 className="mt-5 text-xl font-semibold">{s.t}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{s.d}</p>
              <a href="#contact" className="mt-5 inline-block text-sm text-primary">Request service →</a>
            </div>
          ))}
        </div>
      </section>

      <section id="features" className="py-24 container mx-auto px-4">
        <Heading eyebrow="Why us" title="No-surprise service" />
        <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {[
            { t: "Upfront pricing", d: "Quote before we start. No hidden fees." },
            { t: "Same-day service", d: "Most jobs scheduled within 24 hours." },
            { t: "1-year guarantee", d: "Workmanship covered for 12 months." },
            { t: "Licensed & insured", d: "Fully bonded California contractors." },
          ].map((f) => (
            <div key={f.t} className="rounded-2xl bg-card border border-border/60 p-6">
              <ShieldCheck className="size-6 text-primary" />
              <h3 className="mt-4 font-semibold">{f.t}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{f.d}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="testimonials" className="py-24 container mx-auto px-4">
        <Heading eyebrow="Testimonials" title="What homeowners say" />
        <div className="mt-12 grid md:grid-cols-3 gap-5">
          {[
            { n: "Sarah M.", q: "Fixed our heater in two hours. Friendly and clean." },
            { n: "Greg L.", q: "Honest quote and great workmanship. Highly recommend." },
            { n: "Nina O.", q: "Saved us a fortune on a re-pipe. Will use again." },
          ].map((t) => (
            <div key={t.n} className="glass rounded-2xl p-6">
              <div className="flex gap-1 text-gold">{Array.from({ length: 5 }).map((_, i) => <Star key={i} className="size-4 fill-current" />)}</div>
              <p className="mt-3 text-sm">"{t.q}"</p>
              <div className="mt-4 text-sm font-semibold">{t.n}</div>
            </div>
          ))}
        </div>
      </section>

      <section id="contact" className="py-24 container mx-auto px-4 max-w-4xl">
        <Heading eyebrow="Contact" title="Get your free quote" />
        <form className="mt-12 glass rounded-3xl p-8 grid sm:grid-cols-2 gap-4" onSubmit={(e) => e.preventDefault()}>
          <input placeholder="Name" className="rounded-xl bg-background border border-border px-4 py-3 text-sm" />
          <input placeholder="Phone" className="rounded-xl bg-background border border-border px-4 py-3 text-sm" />
          <input placeholder="Email" type="email" className="sm:col-span-2 rounded-xl bg-background border border-border px-4 py-3 text-sm" />
          <select className="sm:col-span-2 rounded-xl bg-background border border-border px-4 py-3 text-sm"><option>Service needed…</option><option>Plumbing</option><option>HVAC</option><option>Electrical</option></select>
          <textarea rows={4} placeholder="Describe the job…" className="sm:col-span-2 rounded-xl bg-background border border-border px-4 py-3 text-sm" />
          <button className="sm:col-span-2 rounded-full bg-primary text-primary-foreground px-5 py-3 font-medium shadow-elegant">Send Request</button>
        </form>
        <div className="mt-8 grid sm:grid-cols-3 gap-4 text-sm">
          <Info icon={Phone} t="(415) 555-1234" />
          <Info icon={Mail} t="hello@ortizco.com" />
          <Info icon={MapPin} t="Serving the Bay Area" />
        </div>
      </section>

      <footer className="border-t border-border/60 mt-24 py-8 text-center text-xs text-muted-foreground">© {new Date().getFullYear()} Ortiz & Co. · Demo template by Tadylcor</footer>
    </div>
  );
}

function Stat({ n, l }: { n: string; l: string }) { return <div><div className="text-2xl font-bold text-gradient">{n}</div><div className="text-xs text-muted-foreground mt-1">{l}</div></div>; }
function Heading({ eyebrow, title }: { eyebrow: string; title: string }) { return <div className="text-center"><span className="text-xs uppercase tracking-[0.3em] text-primary font-semibold">{eyebrow}</span><h2 className="mt-3 text-4xl md:text-5xl font-bold">{title}</h2></div>; }
function Info({ icon: Icon, t }: { icon: React.ComponentType<{ className?: string }>; t: string }) { return <div className="flex items-center gap-3 glass rounded-2xl p-4"><Icon className="size-4 text-primary" /><span>{t}</span></div>; }
