import { TemplateNav } from "@/components/TemplateNav";
import { Bed, Bath, Maximize, MapPin, Phone, Mail, Star } from "lucide-react";

const sections = [
  { id: "home", label: "Home" },
  { id: "about", label: "Agent" },
  { id: "services", label: "Listings" },
  { id: "features", label: "Featured" },
  { id: "testimonials", label: "Reviews" },
  { id: "contact", label: "Contact" },
];

const listings = [
  { t: "Modern Hillside Retreat", loc: "Oakland, CA", price: "$1,895,000", beds: 4, baths: 3, sqft: 2850, tag: "New" },
  { t: "Downtown Loft", loc: "San Francisco, CA", price: "$1,150,000", beds: 2, baths: 2, sqft: 1420, tag: "Hot" },
  { t: "Coastal Mid-Century", loc: "Half Moon Bay, CA", price: "$2,450,000", beds: 5, baths: 4, sqft: 3600, tag: "Featured" },
  { t: "Garden Townhouse", loc: "Berkeley, CA", price: "$985,000", beds: 3, baths: 2, sqft: 1800 },
  { t: "Penthouse with View", loc: "San Francisco, CA", price: "$3,200,000", beds: 3, baths: 3, sqft: 2400, tag: "Featured" },
  { t: "Family Craftsman", loc: "Palo Alto, CA", price: "$2,995,000", beds: 4, baths: 3, sqft: 2700 },
];

export function RealEstateTemplate() {
  return (
    <div className="min-h-screen">
      <TemplateNav brand="Coastline Group" sections={sections} cta={{ label: "Schedule a Call", href: "#contact" }} />

      <section id="home" className="relative min-h-[80vh] flex items-center pt-28 bg-hero">
        <div className="container mx-auto px-4 max-w-3xl animate-fade-up">
          <span className="text-xs uppercase tracking-[0.3em] text-gold">Bay Area Real Estate</span>
          <h1 className="mt-4 text-5xl md:text-7xl font-bold leading-tight">Find a home that <span className="text-gradient">moves you</span></h1>
          <p className="mt-6 text-lg text-muted-foreground">Hand-picked properties across the Bay Area, represented by award-winning agents.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="#services" className="rounded-full bg-primary text-primary-foreground px-6 py-3 font-medium shadow-elegant">Browse Listings</a>
            <a href="#contact" className="rounded-full glass px-6 py-3 font-medium">Talk to an Agent</a>
          </div>
        </div>
      </section>

      <section id="features" className="py-24 container mx-auto px-4">
        <Heading eyebrow="Featured" title="This week's hand-picked listings" />
        <div className="mt-12 grid md:grid-cols-3 gap-5">
          {listings.slice(0, 3).map((l) => <Card key={l.t} l={l} featured />)}
        </div>
      </section>

      <section id="services" className="py-24 container mx-auto px-4">
        <Heading eyebrow="Listings" title="Browse our portfolio" />
        <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {listings.map((l) => <Card key={l.t} l={l} />)}
        </div>
      </section>

      <section id="about" className="py-24 container mx-auto px-4 grid md:grid-cols-2 gap-12 items-center">
        <div className="aspect-square rounded-3xl bg-gradient-to-br from-primary/30 to-gold/30 shadow-elegant max-w-md" />
        <div>
          <span className="text-xs uppercase tracking-[0.3em] text-primary">Your Agent</span>
          <h2 className="mt-3 text-4xl font-bold">Marcus Lee</h2>
          <p className="mt-2 text-gold">Top 1% Realtor · Coastline Group</p>
          <p className="mt-5 text-muted-foreground leading-relaxed">12 years guiding Bay Area buyers and sellers. $450M+ in closed transactions and a network that gets things done.</p>
          <div className="mt-6 grid grid-cols-3 gap-4">
            <Stat n="$450M+" l="Closed" /><Stat n="12 yrs" l="Experience" /><Stat n="4.9★" l="Reviews" />
          </div>
          <div className="mt-6 flex gap-3">
            <a href="#contact" className="rounded-full bg-primary text-primary-foreground px-5 py-2.5 text-sm font-medium">Schedule a Call</a>
            <a href="tel:5550000" className="rounded-full glass px-5 py-2.5 text-sm inline-flex items-center gap-2"><Phone className="size-4" /> (415) 555-0000</a>
          </div>
        </div>
      </section>

      <section id="testimonials" className="py-24 container mx-auto px-4">
        <Heading eyebrow="Reviews" title="Trusted by buyers and sellers" />
        <div className="mt-12 grid md:grid-cols-3 gap-5">
          {[
            { n: "Eli W.", q: "Sold $80k over asking. Marcus is a magician." },
            { n: "Diane R.", q: "Patient, sharp, and incredibly responsive." },
            { n: "Tomás A.", q: "Found our dream home in three weeks." },
          ].map((t) => (
            <div key={t.n} className="glass rounded-2xl p-6">
              <div className="flex gap-1 text-gold">{Array.from({ length: 5 }).map((_, i) => <Star key={i} className="size-4 fill-current" />)}</div>
              <p className="mt-3 text-sm">"{t.q}"</p>
              <div className="mt-4 text-sm font-semibold">{t.n}</div>
            </div>
          ))}
        </div>
      </section>

      <section id="contact" className="py-24 container mx-auto px-4 max-w-3xl">
        <Heading eyebrow="Contact" title="Let's start the conversation" />
        <form className="mt-12 glass rounded-3xl p-8 grid sm:grid-cols-2 gap-4" onSubmit={(e) => e.preventDefault()}>
          <input placeholder="Name" className="rounded-xl bg-background border border-border px-4 py-3 text-sm" />
          <input placeholder="Phone" className="rounded-xl bg-background border border-border px-4 py-3 text-sm" />
          <input placeholder="Email" type="email" className="sm:col-span-2 rounded-xl bg-background border border-border px-4 py-3 text-sm" />
          <select className="sm:col-span-2 rounded-xl bg-background border border-border px-4 py-3 text-sm"><option>I'm interested in…</option><option>Buying</option><option>Selling</option><option>Both</option></select>
          <textarea rows={4} placeholder="Tell me about your goals…" className="sm:col-span-2 rounded-xl bg-background border border-border px-4 py-3 text-sm" />
          <button className="sm:col-span-2 rounded-full bg-primary text-primary-foreground px-5 py-3 font-medium shadow-elegant">Send Message</button>
        </form>
        <div className="mt-8 grid sm:grid-cols-3 gap-4 text-sm">
          <div className="flex items-center gap-3 glass rounded-2xl p-4"><Phone className="size-4 text-primary" /> (415) 555-0000</div>
          <div className="flex items-center gap-3 glass rounded-2xl p-4"><Mail className="size-4 text-primary" /> marcus@coastline.co</div>
          <div className="flex items-center gap-3 glass rounded-2xl p-4"><MapPin className="size-4 text-primary" /> San Francisco, CA</div>
        </div>
      </section>

      <footer className="border-t border-border/60 mt-24 py-8 text-center text-xs text-muted-foreground">© {new Date().getFullYear()} Coastline Group · Demo template by Tadylcor</footer>
    </div>
  );
}

function Card({ l, featured }: { l: typeof listings[number]; featured?: boolean }) {
  return (
    <div className={`group rounded-3xl overflow-hidden border border-border/60 bg-card hover:shadow-elegant transition ${featured ? "ring-1 ring-primary/30" : ""}`}>
      <div className="aspect-[4/3] bg-gradient-to-br from-primary/25 via-accent/20 to-gold/25 relative">
        {l.tag && <span className="absolute top-3 left-3 rounded-full bg-gold text-gold-foreground px-3 py-1 text-xs font-semibold">{l.tag}</span>}
      </div>
      <div className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h3 className="font-semibold">{l.t}</h3>
            <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1"><MapPin className="size-3" /> {l.loc}</p>
          </div>
          <span className="text-gradient font-bold whitespace-nowrap">{l.price}</span>
        </div>
        <div className="mt-4 flex items-center gap-4 text-xs text-muted-foreground border-t border-border/60 pt-3">
          <span className="flex items-center gap-1"><Bed className="size-3.5" /> {l.beds} bd</span>
          <span className="flex items-center gap-1"><Bath className="size-3.5" /> {l.baths} ba</span>
          <span className="flex items-center gap-1"><Maximize className="size-3.5" /> {l.sqft.toLocaleString()} sqft</span>
        </div>
      </div>
    </div>
  );
}

function Stat({ n, l }: { n: string; l: string }) { return <div><div className="text-xl font-bold text-gradient">{n}</div><div className="text-xs text-muted-foreground mt-1">{l}</div></div>; }
function Heading({ eyebrow, title }: { eyebrow: string; title: string }) { return <div className="text-center"><span className="text-xs uppercase tracking-[0.3em] text-primary font-semibold">{eyebrow}</span><h2 className="mt-3 text-4xl md:text-5xl font-bold">{title}</h2></div>; }
