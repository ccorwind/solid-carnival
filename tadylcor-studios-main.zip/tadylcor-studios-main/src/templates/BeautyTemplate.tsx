import { TemplateNav } from "@/components/TemplateNav";
import { Star, Scissors, Calendar, Phone, MapPin } from "lucide-react";

const sections = [
  { id: "home", label: "Home" },
  { id: "about", label: "About" },
  { id: "services", label: "Pricing" },
  { id: "features", label: "Gallery" },
  { id: "testimonials", label: "Reviews" },
  { id: "contact", label: "Booking" },
];

const pricing = [
  { t: "Signature Haircut", p: "$45", d: "Consultation, wash, cut, style." },
  { t: "Beard Sculpt", p: "$25", d: "Trim, line-up, hot towel finish." },
  { t: "Color & Highlights", p: "from $90", d: "Custom color by our senior stylists." },
  { t: "Bridal Package", p: "from $220", d: "Hair, makeup and trial session." },
];

export function BeautyTemplate() {
  return (
    <div className="min-h-screen">
      <TemplateNav brand="The Velvet Chair" sections={sections} cta={{ label: "Book Now", href: "#contact" }} accentClass="bg-gold text-gold-foreground" />

      <section id="home" className="relative min-h-[90vh] flex items-center pt-28 bg-hero">
        <div className="container mx-auto px-4 text-center max-w-3xl animate-fade-up">
          <span className="text-xs uppercase tracking-[0.3em] text-gold">Studio · Salon · Spa</span>
          <h1 className="mt-4 text-5xl md:text-7xl font-bold leading-tight">Look like the <span className="text-gradient">best version</span> of you</h1>
          <p className="mt-6 text-lg text-muted-foreground">Premium haircuts, color and styling in a relaxed, modern studio.</p>
          <a href="#contact" className="mt-8 inline-flex items-center gap-2 rounded-full bg-gold text-gold-foreground px-6 py-3 font-medium shadow-gold"><Calendar className="size-4" /> Book an Appointment</a>
        </div>
      </section>

      <section id="about" className="py-24 container mx-auto px-4 grid md:grid-cols-2 gap-12 items-center">
        <div className="aspect-[4/5] rounded-3xl bg-gradient-to-br from-gold/30 to-primary/30 shadow-gold" />
        <div>
          <span className="text-xs uppercase tracking-[0.3em] text-primary">Our Team</span>
          <h2 className="mt-3 text-4xl font-bold">Stylists who actually listen</h2>
          <p className="mt-5 text-muted-foreground leading-relaxed">Led by master stylist Priya Shah, our team blends classical training with modern technique. Walk in tired — walk out renewed.</p>
          <div className="mt-8 grid grid-cols-3 gap-4">
            {["Priya", "Marcus", "Elena"].map((n) => (
              <div key={n} className="text-center">
                <div className="aspect-square rounded-2xl bg-gradient-to-br from-primary/20 to-gold/20" />
                <div className="mt-2 text-sm font-semibold">{n}</div>
                <div className="text-xs text-muted-foreground">Senior stylist</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="services" className="py-24 container mx-auto px-4">
        <Heading eyebrow="Pricing" title="Services & rates" />
        <div className="mt-12 grid md:grid-cols-2 gap-5">
          {pricing.map((p) => (
            <div key={p.t} className="glass rounded-2xl p-6 flex items-start justify-between gap-4 hover:shadow-gold transition">
              <div>
                <div className="flex items-center gap-2"><Scissors className="size-4 text-gold" /><h3 className="text-lg font-semibold">{p.t}</h3></div>
                <p className="mt-1 text-sm text-muted-foreground">{p.d}</p>
              </div>
              <span className="text-gold font-semibold whitespace-nowrap">{p.p}</span>
            </div>
          ))}
        </div>
      </section>

      <section id="features" className="py-24 container mx-auto px-4">
        <Heading eyebrow="Gallery" title="Recent work" />
        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-3">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className={`rounded-2xl bg-gradient-to-br ${i % 3 === 0 ? "from-gold/40 to-primary/30" : i % 3 === 1 ? "from-primary/30 to-accent/30" : "from-accent/30 to-gold/30"} ${i % 2 === 0 ? "aspect-[3/4]" : "aspect-square"} shadow-soft`} />
          ))}
        </div>
      </section>

      <section id="testimonials" className="py-24 container mx-auto px-4">
        <Heading eyebrow="Reviews" title="Loved by our clients" />
        <div className="mt-12 grid md:grid-cols-3 gap-5">
          {[
            { n: "Jen K.", q: "Best haircut I've had in 10 years. The studio is gorgeous." },
            { n: "Amir S.", q: "Priya nailed exactly what I asked for. Booking online was easy." },
            { n: "Talia B.", q: "Color came out perfect — got compliments all week." },
          ].map((t) => (
            <div key={t.n} className="glass rounded-2xl p-6">
              <div className="flex gap-1 text-gold">{Array.from({ length: 5 }).map((_, i) => <Star key={i} className="size-4 fill-current" />)}</div>
              <p className="mt-3 text-sm">"{t.q}"</p>
              <div className="mt-4 text-sm font-semibold">{t.n}</div>
            </div>
          ))}
        </div>
      </section>

      <section id="contact" className="py-24 container mx-auto px-4 max-w-3xl">
        <Heading eyebrow="Booking" title="Reserve your chair" />
        <form className="mt-12 glass rounded-3xl p-8 grid sm:grid-cols-2 gap-4" onSubmit={(e) => e.preventDefault()}>
          <input placeholder="Name" className="rounded-xl bg-background border border-border px-4 py-3 text-sm" />
          <input placeholder="Phone" className="rounded-xl bg-background border border-border px-4 py-3 text-sm" />
          <select className="sm:col-span-2 rounded-xl bg-background border border-border px-4 py-3 text-sm"><option>Choose a service…</option>{pricing.map((p) => <option key={p.t}>{p.t}</option>)}</select>
          <input type="date" className="rounded-xl bg-background border border-border px-4 py-3 text-sm" />
          <input type="time" className="rounded-xl bg-background border border-border px-4 py-3 text-sm" />
          <button className="sm:col-span-2 rounded-full bg-gold text-gold-foreground px-5 py-3 font-medium shadow-gold">Confirm Appointment</button>
        </form>
        <div className="mt-8 grid sm:grid-cols-2 gap-4 text-sm">
          <div className="flex items-center gap-3 glass rounded-2xl p-4"><Phone className="size-4 text-gold" /> (415) 555-9988</div>
          <div className="flex items-center gap-3 glass rounded-2xl p-4"><MapPin className="size-4 text-gold" /> 88 Hayes St, Suite 2</div>
        </div>
      </section>

      <footer className="border-t border-border/60 mt-24 py-8 text-center text-xs text-muted-foreground">© {new Date().getFullYear()} The Velvet Chair · Demo template by Tadylcor</footer>
    </div>
  );
}

function Heading({ eyebrow, title }: { eyebrow: string; title: string }) { return <div className="text-center"><span className="text-xs uppercase tracking-[0.3em] text-primary font-semibold">{eyebrow}</span><h2 className="mt-3 text-4xl md:text-5xl font-bold">{title}</h2></div>; }
