import { createFileRoute, notFound } from "@tanstack/react-router";
import { RestaurantTemplate } from "@/templates/RestaurantTemplate";
import { ServiceTemplate } from "@/templates/ServiceTemplate";
import { BeautyTemplate } from "@/templates/BeautyTemplate";
import { RealEstateTemplate } from "@/templates/RealEstateTemplate";
import { PortfolioTemplate } from "@/templates/PortfolioTemplate";

const meta: Record<string, { title: string; desc: string }> = {
  restaurant: { title: "Restaurant Template Demo — Tadylcor", desc: "Modern restaurant website template with menu, reservations and reviews." },
  service: { title: "Local Service Template Demo — Tadylcor", desc: "Service business website with cards, testimonials and contact form." },
  beauty: { title: "Beauty & Barber Template Demo — Tadylcor", desc: "Booking-ready barber and beauty studio website template." },
  realestate: { title: "Real Estate Template Demo — Tadylcor", desc: "Property listings, agent profile and contact for real estate." },
  portfolio: { title: "Portfolio Template Demo — Tadylcor", desc: "Creative portfolio template with gallery and about." },
};

export const Route = createFileRoute("/templates/$slug")({
  beforeLoad: ({ params }) => {
    if (!(params.slug in meta)) throw notFound();
  },
  head: ({ params }) => {
    const m = meta[params.slug] ?? meta.restaurant;
    return {
      meta: [
        { title: m.title },
        { name: "description", content: m.desc },
        { property: "og:title", content: m.title },
        { property: "og:description", content: m.desc },
        { property: "og:url", content: `/templates/${params.slug}` },
      ],
      links: [{ rel: "canonical", href: `/templates/${params.slug}` }],
    };
  },
  component: TemplatePage,
});

function TemplatePage() {
  const { slug } = Route.useParams();
  switch (slug) {
    case "restaurant": return <RestaurantTemplate />;
    case "service": return <ServiceTemplate />;
    case "beauty": return <BeautyTemplate />;
    case "realestate": return <RealEstateTemplate />;
    case "portfolio": return <PortfolioTemplate />;
    default: return null;
  }
}
