import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import {
  ArrowRight, Sparkles, Check, Star, Utensils, Wrench, Scissors, Home, Palette,
  Zap, Shield, Smartphone, Search, Send,
} from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import heroBg from "@/assets/hero-bg.jpg";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "Tadylcor — Premium Website Templates & Custom Builds" },
      { name: "description", content: "Build your online presence with Tadylcor. Explore professional website templates and interactive demos designed for businesses and creators." },
      { property: "og:title", content: "Tadylcor — Premium Website Templates" },
      { property: "og:description", content: "Professional website templates and custom builds for businesses and creators." },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
    scripts: [{
      type: "application/ld+json",
      children: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "Organization",
        name: "Tadylcor",
        url: "https://tadylcor.com",
        description: "Premium website templates and custom website builds.",
      }),
    }],
  }),
});

const templates = [
  { slug: "restaurant", title: "Modern Restaurant", category: "Hospitality", description: "Hero, menu, reservations and reviews — perfect for restaurants and cafés.", icon: Utensils },
  { slug: "service", title: "Local Service Business", category: "Services", description: "Service cards, testimonials and lead capture for trades and consultants.", icon: Wrench },
  { slug: "beauty", title: "Barber / Beauty Studio", category: "Beauty", description: "Pricing, gallery, team and online appointment booking.", icon: Scissors },
  { slug: "realestate", title: "Real Estate Agency", category: "Real Estate", description: "Featured listings, property cards and agent profiles.", icon: Home },
  { slug: "portfolio", title: "Portfolio / Creative", category: "Creator", description: "Showcase your work with a polished gallery and about section.", icon: Palette },
] as const;

const pricing = [
  { tier: "Starter Websites", price: "$499 – $999", desc: "Up to 5 pages, template-based design, contact form, mobile responsive.", features: ["Template customization", "1 round of revisions", "Launch in 5–7 days", "Basic SEO setup"] },
  { tier: "Business Websites", price: "$1,000 – $2,500", desc: "Custom design, multiple sections, CMS integration, advanced SEO.", features: ["Custom design", "3 rounds of revisions", "CMS / blog setup", "Analytics & SEO"], featured: true },
  { tier: "Custom Websites", price: "Contact for details", desc: "Bespoke builds, integrations, e-commerce, and ongoing partnership.", features: ["Bespoke design system", "Unlimited revisions", "Integrations & APIs", "Priority support"] },
];

const testimonials = [
  { name: "Maya Carter", role: "Founder, Saffron & Sage", quote: "Tadylcor relaunched our restaurant site in under a week. Bookings doubled in the first month.", rating: 5 },
  { name: "Daniel Ortiz", role: "Owner, Ortiz Plumbing Co.", quote: "Clean, fast, and we finally rank on the first page. The team handled everything.", rating: 5 },
  { name: "Priya Shah", role: "Independent Stylist", quote: "My booking page looks like a million bucks and clients book themselves now.", rating: 5 },
  { name: "Marcus Lee", role: "Realtor, Coastline Group", quote: "Beautiful listings, smooth UX, and my agent profile finally feels professional.", rating: 5 },
];

const faqs = [
  { q: "How long does a website take?", a: "Starter sites usually launch in 5–7 days. Business builds take 2–4 weeks. Fully custom projects depend on scope — we share a clear timeline after our discovery call." },
  { q: "Can I customize templates?", a: "Absolutely. Every template is a starting point — colors, fonts, copy, imagery and sections can be tailored to your brand." },
  { q: "Do you offer maintenance?", a: "Yes. We offer monthly maintenance plans covering updates, backups, performance monitoring, and small content changes." },
  { q: "Can I use my own domain?", a: "Of course. We help you connect your existing domain or register a new one. SSL and DNS setup is handled for you." },
];

function Index() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <Hero />
      <TrustStrip />
      <TemplateGallery />
      <Features />
      <Pricing />
      <About />
      <Testimonials />
      <FAQ />
      <Contact />
      <SiteFooter />
    </div>
  );
}

function Hero() {
  return (
    <section id="home" className="relative pt-36 pb-24 overflow-hidden">
      <img
        src={heroBg}
        alt=""
        aria-hidden
        className="absolute inset-0 w-full h-full object-cover opacity-40 -z-10"
        width={1920}
        height={1280}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/60 to-background -z-10" />
      <div className="container mx-auto px-4 text-center max-w-4xl animate-fade-up">
        <span className="inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-xs text-muted-foreground">
          <Sparkles className="size-3.5 text-gold" />
          Now serving premium templates for 2026
        </span>
        <h1 className="mt-6 text-5xl sm:text-6xl md:text-7xl font-bold leading-[1.05]">
          Build your online presence with <span className="text-gradient">Tadylcor</span>
        </h1>
        <p className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto">
          Explore professional website templates and interactive demos designed for businesses and creators.
        </p>
        <div className="mt-10 flex flex-wrap justify-center gap-3">
          <a href="#templates" className="inline-flex items-center gap-2 rounded-full bg-primary text-primary-foreground px-6 py-3 font-medium shadow-elegant hover:opacity-90 transition">
            Explore Templates <ArrowRight className="size-4" />
          </a>
          <a href="#contact" className="inline-flex items-center gap-2 rounded-full border border-border glass px-6 py-3 font-medium hover:bg-muted/30 transition">
            Request Custom Website
          </a>
        </div>
      </div>
    </section>
  );
}

function TrustStrip() {
  const items = ["Trusted by 200+ local businesses", "Average launch: 6 days", "4.9/5 client satisfaction", "SEO-ready by default"];
  return (
    <div className="border-y border-border/60 bg-card/30">
      <div className="container mx-auto px-4 py-6 grid grid-cols-2 md:grid-cols-4 gap-4 text-center text-xs uppercase tracking-wider text-muted-foreground">
        {items.map((i) => <div key={i}>{i}</div>)}
      </div>
    </div>
  );
}

function TemplateGallery() {
  return (
    <section id="templates" className="py-24">
      <div className="container mx-auto px-4">
        <SectionHeader eyebrow="Templates" title="Designed for every kind of business" subtitle="Five production-ready templates you can demo, customize, and launch in days." />
        <div className="mt-14 grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {templates.map((t, i) => {
            const Icon = t.icon;
            return (
              <div key={t.slug} className="group glass rounded-3xl p-7 hover:shadow-elegant transition animate-fade-up" style={{ animationDelay: `${i * 60}ms` }}>
                <div className="flex items-center gap-3">
                  <span className="h-11 w-11 rounded-xl bg-gradient-to-br from-primary/30 to-gold/30 flex items-center justify-center">
                    <Icon className="size-5 text-primary" />
                  </span>
                  <span className="text-xs uppercase tracking-wider text-muted-foreground">{t.category}</span>
                </div>
                <h3 className="mt-5 text-xl font-semibold">{t.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{t.description}</p>
                <div className="mt-6 flex flex-wrap gap-2">
                  <Link to="/templates/$slug" params={{ slug: t.slug }} className="inline-flex items-center gap-1.5 rounded-full bg-primary text-primary-foreground px-4 py-2 text-sm font-medium hover:opacity-90 transition">
                    View Demo <ArrowRight className="size-3.5" />
                  </Link>
                  <a href="#contact" className="inline-flex items-center rounded-full border border-border px-4 py-2 text-sm hover:bg-muted/30 transition">
                    Customize
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function Features() {
  const features = [
    { icon: Zap, title: "Fast loading", desc: "Optimized for Core Web Vitals out of the box." },
    { icon: Smartphone, title: "Mobile-first", desc: "Pixel-perfect on every screen size." },
    { icon: Search, title: "SEO-ready", desc: "Semantic HTML, sitemaps and meta in place." },
    { icon: Shield, title: "Secure & maintained", desc: "SSL, backups, and ongoing support available." },
  ];
  return (
    <section id="features" className="py-24">
      <div className="container mx-auto px-4">
        <SectionHeader eyebrow="Features" title="Built to convert. Made to last." subtitle="Every template ships with the essentials a modern site needs." />
        <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {features.map((f) => (
            <div key={f.title} className="rounded-2xl bg-card p-6 border border-border/60 hover:border-primary/40 transition">
              <f.icon className="size-6 text-primary" />
              <h3 className="mt-4 font-semibold">{f.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Pricing() {
  return (
    <section id="pricing" className="py-24">
      <div className="container mx-auto px-4">
        <SectionHeader eyebrow="Pricing" title="Transparent, flexible packages" subtitle="From quick-launch sites to fully custom builds — we have a plan for every stage." />
        <div className="mt-14 grid md:grid-cols-3 gap-6">
          {pricing.map((p) => (
            <div key={p.tier} className={`rounded-3xl p-8 border transition ${p.featured ? "bg-gradient-to-b from-primary/15 to-card border-primary/40 shadow-elegant scale-[1.02]" : "bg-card border-border/60"}`}>
              {p.featured && <span className="inline-block mb-3 rounded-full bg-gold text-gold-foreground px-3 py-1 text-xs font-semibold">Most popular</span>}
              <h3 className="text-lg font-semibold">{p.tier}</h3>
              <p className="mt-3 text-3xl font-bold text-gradient">{p.price}</p>
              <p className="mt-3 text-sm text-muted-foreground">{p.desc}</p>
              <ul className="mt-6 space-y-2.5 text-sm">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-2">
                    <Check className="size-4 text-primary shrink-0 mt-0.5" /> {f}
                  </li>
                ))}
              </ul>
              <a href="#contact" className={`mt-7 inline-flex w-full justify-center rounded-full px-5 py-3 text-sm font-medium transition ${p.featured ? "bg-primary text-primary-foreground hover:opacity-90" : "border border-border hover:bg-muted/30"}`}>
                Request a Quote
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function About() {
  return (
    <section id="about" className="py-24">
      <div className="container mx-auto px-4 grid md:grid-cols-2 gap-12 items-center">
        <div>
          <SectionHeader eyebrow="About" title="Modern sites, made simple." align="left" />
          <p className="mt-6 text-muted-foreground leading-relaxed">
            Tadylcor helps businesses and creators launch modern websites with customizable templates and tailored designs. We blend premium aesthetics with practical engineering — so every project loads fast, ranks well, and converts visitors into customers.
          </p>
          <div className="mt-8 grid grid-cols-3 gap-6">
            {[["200+", "Sites launched"], ["98%", "Client retention"], ["6 days", "Avg. launch time"]].map(([n, l]) => (
              <div key={l}>
                <div className="text-2xl font-bold text-gradient">{n}</div>
                <div className="text-xs text-muted-foreground mt-1">{l}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="relative">
          <div className="aspect-square rounded-3xl bg-gradient-to-br from-primary/30 via-accent/20 to-gold/30 shadow-elegant" />
          <div className="absolute -bottom-6 -left-6 glass rounded-2xl p-5 w-56 shadow-soft">
            <div className="flex items-center gap-1 text-gold">{Array.from({ length: 5 }).map((_, i) => <Star key={i} className="size-4 fill-current" />)}</div>
            <p className="mt-2 text-sm">"Genuinely the easiest agency we've worked with."</p>
          </div>
        </div>
      </div>
    </section>
  );
}

function Testimonials() {
  return (
    <section id="testimonials" className="py-24">
      <div className="container mx-auto px-4">
        <SectionHeader eyebrow="Testimonials" title="What our clients say" />
        <div className="mt-14 grid md:grid-cols-2 lg:grid-cols-4 gap-5">
          {testimonials.map((t) => (
            <div key={t.name} className="glass rounded-2xl p-6">
              <div className="flex gap-1 text-gold">
                {Array.from({ length: t.rating }).map((_, i) => <Star key={i} className="size-4 fill-current" />)}
              </div>
              <p className="mt-3 text-sm leading-relaxed">"{t.quote}"</p>
              <div className="mt-5 text-sm">
                <div className="font-semibold">{t.name}</div>
                <div className="text-muted-foreground text-xs">{t.role}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function FAQ() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section id="faq" className="py-24">
      <div className="container mx-auto px-4 max-w-3xl">
        <SectionHeader eyebrow="FAQ" title="Frequently asked questions" />
        <div className="mt-12 space-y-3">
          {faqs.map((f, i) => (
            <button
              key={i}
              onClick={() => setOpen(open === i ? null : i)}
              className="w-full text-left rounded-2xl bg-card border border-border/60 p-6 hover:border-primary/40 transition"
            >
              <div className="flex items-center justify-between gap-4">
                <h3 className="font-semibold">{f.q}</h3>
                <span className={`transition-transform ${open === i ? "rotate-45" : ""} text-primary text-xl`}>+</span>
              </div>
              {open === i && <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{f.a}</p>}
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}

function Contact() {
  const [sent, setSent] = useState(false);
  return (
    <section id="contact" className="py-24">
      <div className="container mx-auto px-4 max-w-3xl">
        <SectionHeader eyebrow="Contact" title="Let's build something great" subtitle="Tell us about your project. We typically respond within one business day." />
        <form
          onSubmit={(e) => { e.preventDefault(); setSent(true); }}
          className="mt-12 glass rounded-3xl p-8 grid sm:grid-cols-2 gap-4"
        >
          <Field label="Name" name="name" required />
          <Field label="Email" name="email" type="email" required />
          <Field label="Phone" name="phone" type="tel" />
          <Field label="Business type" name="business" placeholder="Restaurant, Realtor, Studio…" />
          <div className="sm:col-span-2">
            <label className="text-xs uppercase tracking-wider text-muted-foreground">Project description</label>
            <textarea name="description" rows={4} className="mt-2 w-full rounded-xl bg-background border border-border px-4 py-3 text-sm focus:outline-none focus:border-primary transition" placeholder="A few sentences about what you need…" />
          </div>
          <div className="sm:col-span-2 flex items-center justify-between gap-4">
            <p className="text-xs text-muted-foreground">By submitting you agree to be contacted about your project.</p>
            <button type="submit" className="inline-flex items-center gap-2 rounded-full bg-primary text-primary-foreground px-6 py-3 text-sm font-medium shadow-elegant hover:opacity-90 transition">
              {sent ? "Sent ✓" : <>Send <Send className="size-4" /></>}
            </button>
          </div>
        </form>
      </div>
    </section>
  );
}

function Field({ label, name, type = "text", required = false, placeholder }: { label: string; name: string; type?: string; required?: boolean; placeholder?: string }) {
  return (
    <div>
      <label className="text-xs uppercase tracking-wider text-muted-foreground">{label}{required && " *"}</label>
      <input
        name={name}
        type={type}
        required={required}
        placeholder={placeholder}
        className="mt-2 w-full rounded-xl bg-background border border-border px-4 py-3 text-sm focus:outline-none focus:border-primary transition"
      />
    </div>
  );
}

function SectionHeader({ eyebrow, title, subtitle, align = "center" }: { eyebrow: string; title: string; subtitle?: string; align?: "center" | "left" }) {
  return (
    <div className={align === "center" ? "text-center max-w-2xl mx-auto" : ""}>
      <span className="text-xs uppercase tracking-[0.2em] text-primary font-semibold">{eyebrow}</span>
      <h2 className="mt-3 text-4xl md:text-5xl font-bold">{title}</h2>
      {subtitle && <p className="mt-4 text-muted-foreground">{subtitle}</p>}
    </div>
  );
}
