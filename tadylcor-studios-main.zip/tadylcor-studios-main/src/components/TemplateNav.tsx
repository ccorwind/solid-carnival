import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, Menu, X } from "lucide-react";

interface Props {
  brand: string;
  sections: { id: string; label: string }[];
  cta?: { label: string; href: string };
  accentClass?: string;
}

export function TemplateNav({ brand, sections, cta, accentClass = "bg-primary text-primary-foreground" }: Props) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState<string>(sections[0]?.id ?? "");

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 12);
      // active section
      for (const s of sections) {
        const el = document.getElementById(s.id);
        if (!el) continue;
        const rect = el.getBoundingClientRect();
        if (rect.top <= 120 && rect.bottom >= 120) {
          setActive(s.id);
          break;
        }
      }
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [sections]);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${scrolled ? "py-2" : "py-4"}`}
    >
      <div className="container mx-auto px-4">
        <nav className={`flex items-center justify-between rounded-2xl px-5 py-3 transition-all ${scrolled ? "glass shadow-soft" : "bg-background/40 backdrop-blur"}`}>
          <div className="flex items-center gap-4">
            <Link to="/" className="text-xs text-muted-foreground hover:text-foreground inline-flex items-center gap-1">
              <ArrowLeft className="size-3.5" /> Tadylcor
            </Link>
            <span className="h-4 w-px bg-border" />
            <a href="#home" className="font-display text-lg font-semibold tracking-tight">{brand}</a>
          </div>
          <ul className="hidden md:flex items-center gap-6 text-sm">
            {sections.map((s) => (
              <li key={s.id}>
                <a
                  href={`#${s.id}`}
                  className={`transition-colors ${active === s.id ? "text-foreground" : "text-muted-foreground hover:text-foreground"}`}
                >
                  {s.label}
                </a>
              </li>
            ))}
          </ul>
          {cta && (
            <a href={cta.href} className={`hidden md:inline-flex rounded-full px-5 py-2 text-sm font-medium shadow-elegant ${accentClass}`}>
              {cta.label}
            </a>
          )}
          <button className="md:hidden p-2" onClick={() => setOpen((v) => !v)} aria-label="Toggle menu">
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </nav>
        {open && (
          <div className="md:hidden glass mt-2 rounded-2xl p-4">
            <ul className="flex flex-col gap-2">
              {sections.map((s) => (
                <li key={s.id}>
                  <a href={`#${s.id}`} onClick={() => setOpen(false)} className="block py-2 text-sm">{s.label}</a>
                </li>
              ))}
              {cta && (
                <a href={cta.href} onClick={() => setOpen(false)} className={`rounded-full px-5 py-2 text-sm font-medium text-center ${accentClass}`}>
                  {cta.label}
                </a>
              )}
            </ul>
          </div>
        )}
      </div>
    </header>
  );
}
