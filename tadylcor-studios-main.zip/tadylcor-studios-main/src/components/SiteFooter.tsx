import { Link } from "@tanstack/react-router";

export function SiteFooter() {
  return (
    <footer className="border-t border-border/60 mt-32">
      <div className="container mx-auto px-4 py-12 grid md:grid-cols-4 gap-10 text-sm">
        <div>
          <Link to="/" className="flex items-center gap-2">
            <span className="h-8 w-8 rounded-lg bg-gradient-to-br from-primary to-gold" />
            <span className="font-display text-xl font-semibold">Tadylcor</span>
          </Link>
          <p className="mt-3 text-muted-foreground max-w-xs">
            Premium website templates and custom builds for modern businesses and creators.
          </p>
        </div>
        <div>
          <h4 className="font-semibold mb-3">Templates</h4>
          <ul className="space-y-2 text-muted-foreground">
            <li><Link to="/templates/restaurant" className="hover:text-foreground">Restaurant</Link></li>
            <li><Link to="/templates/service" className="hover:text-foreground">Local Service</Link></li>
            <li><Link to="/templates/beauty" className="hover:text-foreground">Barber / Beauty</Link></li>
            <li><Link to="/templates/realestate" className="hover:text-foreground">Real Estate</Link></li>
            <li><Link to="/templates/portfolio" className="hover:text-foreground">Portfolio</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold mb-3">Company</h4>
          <ul className="space-y-2 text-muted-foreground">
            <li><a href="/#about" className="hover:text-foreground">About</a></li>
            <li><a href="/#pricing" className="hover:text-foreground">Pricing</a></li>
            <li><a href="/#faq" className="hover:text-foreground">FAQ</a></li>
            <li><a href="/#contact" className="hover:text-foreground">Contact</a></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold mb-3">Get in touch</h4>
          <p className="text-muted-foreground">hello@tadylcor.com</p>
          <p className="text-muted-foreground mt-1">Mon–Fri · 9am–6pm</p>
        </div>
      </div>
      <div className="border-t border-border/60 py-6 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} Tadylcor. All rights reserved.
      </div>
    </footer>
  );
}
